from . import print

__all__ = ["print"]
